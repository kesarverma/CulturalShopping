import React from 'react'

export default function Slider() {
  return (
    <div className="section1">
        <div className="img-slider">
        <img src="https://i.ytimg.com/vi/5xeGxGJ00B4/maxresdefault.jpg" alt="" className="img"></img>
        <img src="https://www.connectingtraveller.com/images/localtip/1626476047bazar4.jpg" alt="" className="img"></img>
        <img src="https://blog.thomascook.in/wp-content/uploads/2018/04/kochi-1.jpg" alt="" className="img"></img>
        <img src="https://www.shoppersgossip.com/wp-content/uploads/2019/08/what-to-buy-in-guwahati.jpg" alt="" className="img"></img>
        <img src="https://www.holidify.com/images/cmsuploads/compressed/souvenirs_20190814134709.jpg" alt="" className="img"></img>
        </div>
    </div>
  )
}
